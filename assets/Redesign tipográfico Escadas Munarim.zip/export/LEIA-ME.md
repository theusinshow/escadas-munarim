# Escadas Munarim — marca 1a

Todos os arquivos usam a mesma caixa: **525 × 155**, com a marca alinhada à esquerda em x = 13,89.
Largura mínima de aplicação: **240px**.

## Cores

    linha e ®     #9FA9B3   (no navy: #B9C0C7)
    palavra       #2C445F   (no navy: #FFFFFF)
    fundo navy    #2C445F

## Os arquivos

| Arquivo | O que é | Onde usar |
|---|---|---|
| `munarim-1a-claro.svg` | Contornos reais da marca, fundo transparente | Web, papel, qualquer coisa clara |
| `munarim-1a-navy.svg` | Mesma marca invertida sobre o navy | Faixas escuras, capa, rodapé |
| `munarim-1a-mono.svg` | Uma cor só, em `currentColor` | Carimbo, serigrafia, fax, corte a laser |
| `munarim-1a-animado.svg` | O traço se desenhando e a palavra entrando | Só navegador — 1,66s, respeita `prefers-reduced-motion` |
| `munarim-1a-texto-michroma.svg` | Texto vivo em Michroma, não contorno | Quando alguém precisar editar a palavra |
| `png/*.png` | 1050 e 2100px de largura, fundo transparente ou navy | WhatsApp, apresentação, quem não abre SVG |

## Qual usar

**Contorno (`claro`, `navy`, `mono`) é o padrão.** Não depende de fonte instalada,
abre igual em qualquer lugar e é a letra original da marca.

O `texto-michroma` existe para o caso de precisarem reescrever a palavra. A Michroma
é a Eurostile livre: mesmo esqueleto quadrado e mesma largura, mas peso mais gordo
que o original. Não é substituta da marca — é rascunho editável.

O `animado` só toca em navegador. Em e-mail, PowerPoint ou impressão ele aparece
no quadro final, que é idêntico ao `claro`.

## O que falta

- **PDF e EPS** saem de qualquer um dos SVG abrindo no Illustrator e salvando —
  os contornos já estão fechados, não há texto vivo para converter.
- **Favicon** não sai daqui: 525 × 155 não cabe num quadrado. Use o modelo 1c
  reduzido (só a escada), que foi desenhado para isso.
